### Statistiques descriptives  
#### BMI par gender  
**Data frame:** tobacco  
**�tiquette:** Body Mass Index  
**N:** 489  

|            &nbsp; |      F |      M |
|------------------:|-------:|-------:|
|           **Moy** |  26.10 |  25.31 |
|    **�cart-type** |   4.95 |   3.98 |
|           **Min** |   9.01 |   8.83 |
|            **Q1** |  22.98 |  22.52 |
|       **M�diane** |  25.87 |  25.14 |
|            **Q3** |  29.48 |  27.96 |
|           **Max** |  39.44 |  36.76 |
|           **�MA** |   4.75 |   4.02 |
|           **�IQ** |   6.49 |   5.44 |
|            **CV** |   0.19 |   0.16 |
|     **Asym�trie** |  -0.02 |  -0.04 |
|  **ET-Asym�trie** |   0.11 |   0.11 |
| **Aplatissement** |   0.09 |   0.17 |
|     **Nb.Valide** | 475.00 | 477.00 |
|      **% Valide** |  97.14 |  97.55 |
