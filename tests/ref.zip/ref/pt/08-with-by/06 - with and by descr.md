### Estat�stica descritiva  
#### BMI por gender  
**Data Frame:** tobacco  
**R�tulo:** Body Mass Index  
**N:** 489  

|            &nbsp; |      F |      M |
|------------------:|-------:|-------:|
|         **M�dia** |  26.10 |  25.31 |
|   **Desv.padr�o** |   4.95 |   3.98 |
|           **M�n** |   9.01 |   8.83 |
|            **Q1** |  22.98 |  22.52 |
|       **Mediana** |  25.87 |  25.14 |
|            **Q3** |  29.48 |  27.96 |
|           **M�x** |  39.44 |  36.76 |
|           **MDA** |   4.75 |   4.02 |
|           **IQE** |   6.49 |   5.44 |
|            **CV** |   0.19 |   0.16 |
|    **Assimetria** |  -0.02 |  -0.04 |
| **EP.Assimetria** |   0.11 |   0.11 |
|       **Curtose** |   0.09 |   0.17 |
|     **N.V�lidos** | 475.00 | 477.00 |
|      **% V�lido** |  97.14 |  97.55 |
