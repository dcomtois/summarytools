### Tanimlayici Istatistikler  
#### BMI g�re gender  
**Veri �er�evesi:** tobacco  
**Etiket:** Body Mass Index  
**N:** 489  

|           &nbsp; |      F |      M |
|-----------------:|-------:|-------:|
|     **Ortalama** |  26.10 |  25.31 |
|      **Std.Sap** |   4.95 |   3.98 |
|          **Min** |   9.01 |   8.83 |
|           **Q1** |  22.98 |  22.52 |
|       **Medyan** |  25.87 |  25.14 |
|           **Q3** |  29.48 |  27.96 |
|          **Mak** |  39.44 |  36.76 |
|          **OMS** |   4.75 |   4.02 |
|           **�A** |   6.49 |   5.44 |
|           **CV** |   0.19 |   0.16 |
|    **�arpiklik** |  -0.02 |  -0.04 |
| **�arpiklik.SH** |   0.11 |   0.11 |
|     **Basiklik** |   0.09 |   0.17 |
|    **Ge�erli.N** | 475.00 | 477.00 |
|    **Ge�erli %** |  97.14 |  97.55 |
